function x = kNegEntr(n)
%KNEGENTR Function definition: h(x) = x log(x).

x = 11;

if nargin == 1
  x = x * ones(n, 1);
end