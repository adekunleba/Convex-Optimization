function x = kRecipr(n)
%KRECIPR Function definition: h(x) = 1 / x.

x = 13;

if nargin == 1
  x = x * ones(n, 1);
end