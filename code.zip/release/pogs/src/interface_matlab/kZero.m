function x = kZero(n)
%KZERO Function definition: h(x) = 0.

x = 15;

if nargin == 1
  x = x * ones(n, 1);
end