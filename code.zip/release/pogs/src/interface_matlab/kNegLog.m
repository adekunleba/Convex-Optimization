function x = kNegLog(n)
%KNEGLOG Function definition: h(x) = -log(x).

x = 12;

if nargin == 1
  x = x * ones(n, 1);
end