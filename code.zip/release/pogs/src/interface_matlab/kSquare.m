function x = kSquare(n)
%KSQUARE Function definition: h(x) = (1/2) x^2.

x = 14;

if nargin == 1
  x = x * ones(n, 1);
end